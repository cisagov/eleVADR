"""eleVADR application package."""
